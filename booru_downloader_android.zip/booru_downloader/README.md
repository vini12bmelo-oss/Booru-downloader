# Booru Downloader — Android

App Flutter para baixar imagens e vídeos de sites booru (Safebooru, Danbooru, Yande.re, etc).

---

## Como instalar no celular (sem PC)

### Passo 1 — Crie uma conta no GitHub
Acesse https://github.com e crie uma conta gratuita.

### Passo 2 — Crie um repositório novo
- Clique em **New repository**
- Nome: `booru-downloader`
- Visibilidade: **Public** (obrigatório para Actions gratuito)
- Clique em **Create repository**

### Passo 3 — Suba os arquivos
No repositório criado, clique em **uploading an existing file** e suba todos os arquivos e pastas deste projeto, mantendo a estrutura de pastas igual.

> Dica: você pode zipar a pasta do projeto e extrair no GitHub, ou usar o GitHub Desktop.

### Passo 4 — Aguarde o build
Após o upload, vá na aba **Actions** do repositório. O GitHub vai compilar o APK automaticamente (leva ~5 minutos).

### Passo 5 — Baixe o APK
Quando terminar (check verde ✅), clique no workflow → clique em **booru-downloader** em Artifacts → baixe o ZIP → extraia o `app-debug.apk`.

### Passo 6 — Instale no Android
- No celular, abra o APK baixado
- Se pedir, ative **"Instalar de fontes desconhecidas"** nas configurações
- Instale e abra o app!

---

## Onde os arquivos são salvos?

Os arquivos baixados ficam em:
```
Armazenamento interno/Android/data/com.example.booru_downloader/files/BooruDownloader/
  <tag>/
    Imagens/
      Censuradas/
    Videos/
```

Acesse pelo gerenciador de arquivos do celular.

---

## Estrutura do projeto
```
booru_downloader/
├── .github/workflows/build.yml   ← build automático
├── android/
│   └── app/src/main/
│       └── AndroidManifest.xml
├── lib/
│   ├── main.dart
│   ├── home_page.dart            ← interface
│   └── booru_client.dart         ← API + downloads
└── pubspec.yaml
```
