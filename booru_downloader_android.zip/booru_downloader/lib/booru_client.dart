import 'dart:io';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';

// ─────────────────────────────────────────────────────────────────────────────
//  API Style
// ─────────────────────────────────────────────────────────────────────────────

enum ApiStyle { gelbooru, danbooru }

// ─────────────────────────────────────────────────────────────────────────────
//  BooruPost
// ─────────────────────────────────────────────────────────────────────────────

class BooruPost {
  final String fileUrl;
  final String sampleUrl;
  final String previewUrl;
  final String tags;

  const BooruPost({
    required this.fileUrl,
    required this.sampleUrl,
    required this.previewUrl,
    required this.tags,
  });

  String get bestUrl {
    if (fileUrl.isNotEmpty) return _fixUrl(fileUrl);
    if (sampleUrl.isNotEmpty) return _fixUrl(sampleUrl);
    return _fixUrl(previewUrl);
  }

  static String _fixUrl(String url) =>
      url.startsWith('//') ? 'https:$url' : url;

  bool get isVideo {
    final u = bestUrl.toLowerCase().split('?').first;
    return u.endsWith('.mp4') || u.endsWith('.webm') ||
        u.endsWith('.mkv') || u.endsWith('.mov') || u.endsWith('.avi');
  }

  bool get isCensored {
    const censorTags = [
      'censored', 'mosaic_censoring', 'bar_censor',
      'partially_censored', 'censor_bar', 'censorship', 'pixel_censoring',
      'light_censoring',
    ];
    final t = tags.toLowerCase();
    return censorTags.any(t.contains);
  }

  String get filename {
    final u = bestUrl.split('?').first;
    return Uri.parse(u).pathSegments.last;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  BooruClient
// ─────────────────────────────────────────────────────────────────────────────

class BooruClient {
  final String apiBase;
  final ApiStyle style;
  final Dio _dio;

  static const _maxPerPage = 100;

  BooruClient(String apiBase)
      : apiBase = apiBase.trimRight().replaceAll(RegExp(r'/$'), ''),
        style = _detectStyle(apiBase),
        _dio = Dio(BaseOptions(
          headers: {'User-Agent': 'BooruDownloader_Flutter/1.0'},
          connectTimeout: const Duration(seconds: 15),
          receiveTimeout: const Duration(seconds: 60),
        ));

  static ApiStyle _detectStyle(String url) {
    if (url.contains('donmai.us') ||
        url.contains('yande.re') ||
        url.trimRight().endsWith('.json')) {
      return ApiStyle.danbooru;
    }
    return ApiStyle.gelbooru;
  }

  String get styleName =>
      style == ApiStyle.danbooru ? 'Danbooru' : 'Gelbooru';

  Future<List<BooruPost>> fetchPosts(
    String tags,
    int limit,
    void Function(String) onLog, {
    bool Function()? isCancelled,
  }) async {
    onLog('Estilo detectado: $styleName');

    final posts = <BooruPost>[];
    int page = 0;

    while (posts.length < limit) {
      if (isCancelled != null && isCancelled()) break;

      final need = (limit - posts.length).clamp(1, _maxPerPage);
      final String url;

      if (style == ApiStyle.danbooru) {
        url = '$apiBase?tags=${Uri.encodeQueryComponent(tags)}'
            '&limit=$need&page=${page + 1}';
      } else {
        url = '$apiBase?page=dapi&s=post&q=index&json=1'
            '&tags=${Uri.encodeQueryComponent(tags)}&limit=$need&pid=$page';
      }

      onLog('Página ${page + 1} — buscando $need posts...');

      try {
        final resp = await _dio.get<dynamic>(url);
        final data = resp.data;

        List<dynamic> arr = const [];
        if (data is List) {
          arr = data;
        } else if (data is Map) {
          arr = (data['post'] ?? data['posts'] ?? data['data'] ?? const [])
              as List<dynamic>;
        }

        if (arr.isEmpty) break;

        for (final raw in arr) {
          if (raw is! Map) continue;

          String tagStr = '';
          final tagsField = raw['tags'] ?? raw['tag_string'] ?? '';
          if (tagsField is String) {
            tagStr = tagsField;
          } else if (tagsField is List) {
            tagStr = tagsField.join(' ');
          }

          posts.add(BooruPost(
            fileUrl: raw['file_url']?.toString() ?? '',
            sampleUrl: (raw['sample_url'] ?? raw['large_file_url'])
                    ?.toString() ??
                '',
            previewUrl:
                (raw['preview_url'] ?? raw['preview_file_url'])?.toString() ??
                    '',
            tags: tagStr,
          ));
        }

        page++;
        if (arr.length < need) break;
      } on DioException catch (e) {
        onLog('[Erro] ${e.message ?? e.type.name}');
        break;
      } catch (e) {
        onLog('[Erro] $e');
        break;
      }
    }

    return posts.take(limit).toList();
  }

  Future<void> downloadFile(
    String url,
    String destPath, {
    void Function(int received, int total)? onProgress,
    CancelToken? cancelToken,
  }) async {
    await _dio.download(
      url,
      destPath,
      onReceiveProgress: onProgress,
      cancelToken: cancelToken,
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  DownloadManager — gerencia pastas e destinos
// ─────────────────────────────────────────────────────────────────────────────

class DownloadFolders {
  final Directory root;
  final Directory images;
  final Directory censored;
  final Directory videos;

  const DownloadFolders({
    required this.root,
    required this.images,
    required this.censored,
    required this.videos,
  });
}

class DownloadManager {
  static Future<DownloadFolders> createFolders(String tagFolderName) async {
    final base = await getExternalStorageDirectory();
    if (base == null) throw Exception('Armazenamento externo não disponível.');

    final root = Directory('${base.path}/BooruDownloader/$tagFolderName');
    final images = Directory('${root.path}/Imagens');
    final censored = Directory('${images.path}/Censuradas');
    final videos = Directory('${root.path}/Videos');

    await Future.wait([
      root.create(recursive: true),
      images.create(recursive: true),
      censored.create(recursive: true),
      videos.create(recursive: true),
    ]);

    return DownloadFolders(
      root: root,
      images: images,
      censored: censored,
      videos: videos,
    );
  }

  static String resolveDestPath(BooruPost post, DownloadFolders folders) {
    final dir = post.isVideo
        ? folders.videos
        : post.isCensored
            ? folders.censored
            : folders.images;
    return '${dir.path}/${post.filename}';
  }
}
