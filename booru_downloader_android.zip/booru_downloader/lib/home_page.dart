import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'booru_client.dart';

// ─────────────────────────────────────────────────────────────────────────────
//  Constantes / Dados de Sites
// ─────────────────────────────────────────────────────────────────────────────

class SiteOption {
  final String name;
  final String url;
  const SiteOption(this.name, this.url);
}

const _sites = [
  SiteOption('Safebooru', 'https://safebooru.org/index.php'),
  SiteOption('Danbooru', 'https://danbooru.donmai.us/posts.json'),
  SiteOption('Yande.re', 'https://yande.re/post.json'),
  SiteOption('Gelbooru', 'https://gelbooru.com/index.php'),
  SiteOption('Personalizado', ''),
];

// ─────────────────────────────────────────────────────────────────────────────
//  HomePage
// ─────────────────────────────────────────────────────────────────────────────

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // ── Controladores ──────────────────────────────────────────────────────────
  final _tagController = TextEditingController();
  final _customUrlController = TextEditingController();
  final _limitController = TextEditingController(text: '20');
  final _scrollController = ScrollController();
  final _logScrollController = ScrollController();

  // ── Estado ─────────────────────────────────────────────────────────────────
  final List<String> _tags = [];
  int _siteIndex = 0;
  String _formatFilter = 'all';   // all | images | videos
  String _aiFilter = 'allow';     // allow | block | only

  bool _running = false;
  CancelToken? _cancelToken;

  final List<String> _log = [];
  final List<_ResultItem> _results = [];
  int _downloaded = 0;
  int _total = 0;

  // Stats
  int _countImages = 0;
  int _countCensored = 0;
  int _countVideos = 0;

  @override
  void dispose() {
    _tagController.dispose();
    _customUrlController.dispose();
    _limitController.dispose();
    _scrollController.dispose();
    _logScrollController.dispose();
    super.dispose();
  }

  // ── Helpers ────────────────────────────────────────────────────────────────

  void _addLog(String msg) {
    setState(() => _log.add(msg));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_logScrollController.hasClients) {
        _logScrollController.animateTo(
          _logScrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _addTag(String raw) {
    final parts = raw
        .trim()
        .toLowerCase()
        .split(RegExp(r'[,\s]+'))
        .where((s) => s.isNotEmpty)
        .map((s) => s.replaceAll(' ', '_'));

    bool added = false;
    for (final tag in parts) {
      if (!_tags.contains(tag)) {
        _tags.add(tag);
        added = true;
      }
    }
    if (added) {
      setState(() {});
      _tagController.clear();
    }
  }

  String get _apiUrl {
    if (_siteIndex == 4) return _customUrlController.text.trim();
    return _sites[_siteIndex].url;
  }

  String get _folderName => _tags
      .map((t) => t.replaceAll(RegExp(r'[^\w\-]'), ''))
      .join('_e_');

  // ── Download ───────────────────────────────────────────────────────────────

  Future<void> _startDownload() async {
    if (_tags.isEmpty) {
      _showSnack('Adicione pelo menos uma tag.');
      return;
    }
    final apiUrl = _apiUrl;
    if (apiUrl.isEmpty) {
      _showSnack('Informe o URL da API.');
      return;
    }
    final limit = int.tryParse(_limitController.text.trim()) ?? 0;
    if (limit <= 0) {
      _showSnack('Limite inválido.');
      return;
    }

    setState(() {
      _running = true;
      _log.clear();
      _results.clear();
      _downloaded = 0;
      _total = 0;
      _countImages = 0;
      _countCensored = 0;
      _countVideos = 0;
    });

    _cancelToken = CancelToken();

    String searchTags = _tags.join(' ');
    if (_aiFilter == 'block') searchTags += ' -ai-generated';
    if (_aiFilter == 'only') searchTags += ' ai-generated';

    _addLog('Tags: [$searchTags]');
    _addLog('Site: $apiUrl');
    _addLog('Limite: $limit');

    final client = BooruClient(apiUrl);

    // Busca posts
    List<BooruPost> posts;
    try {
      posts = await client.fetchPosts(
        searchTags,
        limit,
        _addLog,
        isCancelled: () => _cancelToken?.isCancelled ?? true,
      );
    } catch (e) {
      _addLog('[Erro fatal] $e');
      setState(() => _running = false);
      return;
    }

    if (posts.isEmpty) {
      _addLog('Nenhum post encontrado.');
      setState(() => _running = false);
      return;
    }

    // Filtra por formato
    final filtered = posts.where((p) {
      if (p.bestUrl.isEmpty) return false;
      if (_formatFilter == 'images' && p.isVideo) return false;
      if (_formatFilter == 'videos' && !p.isVideo) return false;
      return true;
    }).toList();

    _addLog('Após filtros: ${filtered.length} arquivo(s).');
    setState(() => _total = filtered.length);

    // Cria pastas
    DownloadFolders folders;
    try {
      folders = await DownloadManager.createFolders(_folderName);
      _addLog('Pasta raiz: ${folders.root.path}');
    } catch (e) {
      _addLog('[Erro] Não foi possível criar pastas: $e');
      setState(() => _running = false);
      return;
    }

    // Baixa cada arquivo
    for (int i = 0; i < filtered.length; i++) {
      if (_cancelToken?.isCancelled ?? true) break;

      final post = filtered[i];
      final dest = DownloadManager.resolveDestPath(post, folders);
      final file = File(dest);

      final label = post.isVideo
          ? '[Vídeo]'
          : post.isCensored
              ? '[Censurada]'
              : '[Imagem]';

      if (file.existsSync()) {
        _addLog('${i + 1}/${filtered.length} $label Já existe: ${post.filename}');
        _addResult(post, dest, i + 1, filtered.length, alreadyExisted: true);
        continue;
      }

      try {
        await client.downloadFile(
          post.bestUrl,
          dest,
          cancelToken: _cancelToken,
          onProgress: (rcv, total) {
            // progresso granular por arquivo — opcional
          },
        );

        setState(() {
          _downloaded++;
          if (post.isVideo) _countVideos++;
          else if (post.isCensored) _countCensored++;
          else _countImages++;
        });

        _addLog('${i + 1}/${filtered.length} $label ${post.filename}');
        _addResult(post, dest, i + 1, filtered.length);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.cancel) break;
        _addLog('[Falha] ${post.filename} — ${e.message}');
      } catch (e) {
        _addLog('[Falha] ${post.filename} — $e');
      }
    }

    final cancelled = _cancelToken?.isCancelled ?? false;
    _addLog(cancelled
        ? '\n⚠ Download cancelado. $_downloaded arquivo(s) salvos.'
        : '\n✔ Concluído! $_downloaded arquivo(s) salvos.\n'
            '  Imagens: $_countImages  |  Censuradas: $_countCensored  |  Vídeos: $_countVideos');

    setState(() {
      _running = false;
      _cancelToken = null;
    });
  }

  void _cancel() {
    _cancelToken?.cancel('Cancelado pelo usuário');
    setState(() {});
  }

  void _addResult(BooruPost post, String dest, int n, int total,
      {bool alreadyExisted = false}) {
    setState(() {
      _results.add(_ResultItem(
        post: post,
        destPath: dest,
        index: n,
        total: total,
        alreadyExisted: alreadyExisted,
      ));
    });
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating));
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Build
  // ─────────────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: cs.surface,
      appBar: AppBar(
        backgroundColor: cs.surfaceContainerHighest,
        title: const Text('Booru Downloader'),
        centerTitle: true,
        elevation: 0,
      ),
      body: ListView(
        controller: _scrollController,
        padding: const EdgeInsets.all(16),
        children: [
          _buildTagSection(cs),
          const SizedBox(height: 16),
          _buildSiteSection(cs),
          const SizedBox(height: 16),
          _buildLimitSection(),
          const SizedBox(height: 16),
          _buildFormatSection(cs),
          const SizedBox(height: 16),
          _buildAiSection(cs),
          const SizedBox(height: 20),
          _buildDownloadButton(cs),
          if (_running || _results.isNotEmpty || _log.isNotEmpty) ...[
            const SizedBox(height: 16),
            if (_running || _total > 0) _buildProgressSection(cs),
            const SizedBox(height: 12),
            if (_log.isNotEmpty) _buildLogSection(cs),
            if (_results.isNotEmpty) ...[
              const SizedBox(height: 16),
              _buildResultsSection(cs),
            ],
          ],
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Seções da UI
  // ─────────────────────────────────────────────────────────────────────────

  Widget _buildTagSection(ColorScheme cs) {
    return _card(
      cs,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle('Tags de busca'),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _tagController,
                  decoration: const InputDecoration(
                    hintText: 'Ex: cat, sky...',
                    border: OutlineInputBorder(),
                    isDense: true,
                    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  ),
                  onSubmitted: _addTag,
                  textInputAction: TextInputAction.done,
                ),
              ),
              const SizedBox(width: 8),
              FilledButton.icon(
                onPressed: () => _addTag(_tagController.text),
                icon: const Icon(Icons.add, size: 18),
                label: const Text('Adicionar'),
              ),
            ],
          ),
          if (_tags.isNotEmpty) ...[
            const SizedBox(height: 10),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: _tags.asMap().entries.map((e) {
                return Chip(
                  label: Text(e.value),
                  deleteIcon: const Icon(Icons.close, size: 16),
                  onDeleted: () => setState(() => _tags.removeAt(e.key)),
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  backgroundColor: cs.primaryContainer,
                  labelStyle: TextStyle(color: cs.onPrimaryContainer, fontSize: 13),
                );
              }).toList(),
            ),
          ] else ...[
            const SizedBox(height: 8),
            Text('Nenhuma tag adicionada.',
                style: TextStyle(fontSize: 13, color: cs.onSurfaceVariant)),
          ],
        ],
      ),
    );
  }

  Widget _buildSiteSection(ColorScheme cs) {
    return _card(
      cs,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle('Site'),
          const SizedBox(height: 10),
          DropdownButtonFormField<int>(
            value: _siteIndex,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              isDense: true,
              contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            ),
            items: List.generate(_sites.length, (i) {
              return DropdownMenuItem(value: i, child: Text(_sites[i].name));
            }),
            onChanged: (v) => setState(() => _siteIndex = v ?? 0),
          ),
          if (_siteIndex == 4) ...[
            const SizedBox(height: 8),
            TextField(
              controller: _customUrlController,
              decoration: const InputDecoration(
                hintText: 'https://seusite.com/index.php',
                border: OutlineInputBorder(),
                isDense: true,
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildLimitSection() {
    return Row(
      children: [
        const Text('Quantidade máxima:', style: TextStyle(fontSize: 14)),
        const SizedBox(width: 12),
        SizedBox(
          width: 80,
          child: TextField(
            controller: _limitController,
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              isDense: true,
              contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );
  }

  Widget _buildFormatSection(ColorScheme cs) {
    return _card(
      cs,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle('Formato'),
          const SizedBox(height: 6),
          _radioRow('all', 'Imagens e Vídeos', Icons.perm_media, _formatFilter,
              (v) => setState(() => _formatFilter = v)),
          _radioRow('images', 'Apenas Imagens', Icons.image, _formatFilter,
              (v) => setState(() => _formatFilter = v)),
          _radioRow('videos', 'Apenas Vídeos', Icons.videocam, _formatFilter,
              (v) => setState(() => _formatFilter = v)),
        ],
      ),
    );
  }

  Widget _buildAiSection(ColorScheme cs) {
    return _card(
      cs,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle('Conteúdo IA'),
          const SizedBox(height: 6),
          _radioRow('allow', 'Tudo (com e sem IA)', Icons.auto_awesome, _aiFilter,
              (v) => setState(() => _aiFilter = v)),
          _radioRow('block', 'Bloquear IA', Icons.block, _aiFilter,
              (v) => setState(() => _aiFilter = v)),
          _radioRow('only', 'Apenas IA', Icons.smart_toy, _aiFilter,
              (v) => setState(() => _aiFilter = v)),
        ],
      ),
    );
  }

  Widget _buildDownloadButton(ColorScheme cs) {
    if (_running) {
      return FilledButton.icon(
        onPressed: _cancel,
        style: FilledButton.styleFrom(
          backgroundColor: cs.error,
          foregroundColor: cs.onError,
          minimumSize: const Size.fromHeight(52),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        icon: const Icon(Icons.stop_circle_outlined),
        label: const Text('Cancelar', style: TextStyle(fontSize: 16)),
      );
    }
    return FilledButton.icon(
      onPressed: _startDownload,
      style: FilledButton.styleFrom(
        minimumSize: const Size.fromHeight(52),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      icon: const Icon(Icons.download_rounded),
      label: const Text('Iniciar Download', style: TextStyle(fontSize: 16)),
    );
  }

  Widget _buildProgressSection(ColorScheme cs) {
    final progress = _total > 0 ? _downloaded / _total : 0.0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('$_downloaded / $_total arquivos',
                style: const TextStyle(fontSize: 13)),
            Text('${(progress * 100).toStringAsFixed(0)}%',
                style: const TextStyle(fontSize: 13)),
          ],
        ),
        const SizedBox(height: 6),
        LinearProgressIndicator(
          value: _total > 0 ? progress : null,
          borderRadius: BorderRadius.circular(4),
          minHeight: 8,
        ),
        if (!_running && _total > 0) ...[
          const SizedBox(height: 8),
          Wrap(
            spacing: 12,
            children: [
              _statChip(Icons.image, '$_countImages imagens', cs.primary),
              _statChip(Icons.visibility_off, '$_countCensored censuradas', cs.tertiary),
              _statChip(Icons.videocam, '$_countVideos vídeos', cs.secondary),
            ],
          ),
        ],
      ],
    );
  }

  Widget _buildLogSection(ColorScheme cs) {
    return Container(
      height: 140,
      decoration: BoxDecoration(
        color: const Color(0xFF0F1117),
        borderRadius: BorderRadius.circular(10),
      ),
      padding: const EdgeInsets.all(10),
      child: ListView.builder(
        controller: _logScrollController,
        itemCount: _log.length,
        itemBuilder: (_, i) {
          final line = _log[i];
          final isError = line.startsWith('[Erro') || line.startsWith('[Falha');
          final isOk = line.startsWith('✔');
          final color = isError
              ? const Color(0xFFFF6B6B)
              : isOk
                  ? const Color(0xFF69FF69)
                  : const Color(0xFF00D4FF);
          return Padding(
            padding: const EdgeInsets.only(bottom: 2),
            child: Text(line,
                style: TextStyle(
                    fontFamily: 'monospace', fontSize: 11, color: color)),
          );
        },
      ),
    );
  }

  Widget _buildResultsSection(ColorScheme cs) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('${_results.length} resultado(s)',
            style: TextStyle(
                fontSize: 13,
                color: cs.onSurfaceVariant,
                fontWeight: FontWeight.w500)),
        const SizedBox(height: 10),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
            childAspectRatio: 0.85,
          ),
          itemCount: _results.length,
          itemBuilder: (_, i) => _ResultCard(item: _results[i], cs: cs),
        ),
      ],
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Widgets reutilizáveis
  // ─────────────────────────────────────────────────────────────────────────

  Widget _card(ColorScheme cs, {required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cs.surfaceContainerLow,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: cs.outlineVariant.withAlpha(80)),
      ),
      child: child,
    );
  }

  Widget _sectionTitle(String text) {
    return Text(text,
        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600));
  }

  Widget _radioRow(String value, String label, IconData icon, String groupValue,
      void Function(String) onChanged) {
    final selected = groupValue == value;
    return InkWell(
      onTap: () => onChanged(value),
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            Radio<String>(
              value: value,
              groupValue: groupValue,
              onChanged: (v) => onChanged(v!),
              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              visualDensity: VisualDensity.compact,
            ),
            Icon(icon, size: 18,
                color: selected
                    ? Theme.of(context).colorScheme.primary
                    : null),
            const SizedBox(width: 6),
            Text(label, style: const TextStyle(fontSize: 14)),
          ],
        ),
      ),
    );
  }

  Widget _statChip(IconData icon, String label, Color color) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: color),
        const SizedBox(width: 4),
        Text(label, style: TextStyle(fontSize: 12, color: color)),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  _ResultItem / _ResultCard
// ─────────────────────────────────────────────────────────────────────────────

class _ResultItem {
  final BooruPost post;
  final String destPath;
  final int index;
  final int total;
  final bool alreadyExisted;

  const _ResultItem({
    required this.post,
    required this.destPath,
    required this.index,
    required this.total,
    this.alreadyExisted = false,
  });
}

class _ResultCard extends StatelessWidget {
  final _ResultItem item;
  final ColorScheme cs;

  const _ResultCard({required this.item, required this.cs});

  @override
  Widget build(BuildContext context) {
    final post = item.post;
    final isVid = post.isVideo;
    final isCens = !isVid && post.isCensored;

    String badgeLabel;
    Color badgeColor;
    IconData badgeIcon;

    if (isVid) {
      badgeLabel = 'Vídeo';
      badgeColor = cs.secondary;
      badgeIcon = Icons.videocam;
    } else if (isCens) {
      badgeLabel = 'Censurada';
      badgeColor = cs.tertiary;
      badgeIcon = Icons.visibility_off;
    } else {
      badgeLabel = 'Imagem';
      badgeColor = cs.primary;
      badgeIcon = Icons.image;
    }

    return Container(
      decoration: BoxDecoration(
        color: cs.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: cs.outlineVariant.withAlpha(60)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Thumbnail / ícone
          Expanded(
            child: ClipRRect(
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(12)),
              child: isVid
                  ? Container(
                      width: double.infinity,
                      color: cs.secondaryContainer,
                      child: Icon(Icons.play_circle_outline,
                          size: 44, color: cs.onSecondaryContainer),
                    )
                  : Image.file(
                      File(item.destPath),
                      width: double.infinity,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: cs.surfaceContainerHighest,
                        child: Icon(Icons.broken_image_outlined,
                            color: cs.onSurfaceVariant),
                      ),
                    ),
            ),
          ),
          // Info
          Padding(
            padding: const EdgeInsets.all(8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: badgeColor.withAlpha(30),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(badgeIcon, size: 11, color: badgeColor),
                      const SizedBox(width: 3),
                      Text(badgeLabel,
                          style:
                              TextStyle(fontSize: 10, color: badgeColor, fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  post.filename,
                  style:
                      TextStyle(fontSize: 10, color: cs.onSurfaceVariant),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
